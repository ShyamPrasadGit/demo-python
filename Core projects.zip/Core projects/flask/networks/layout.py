from tkinter import  *
def send():
    message=entry.get()
    listbox.insert('end',message)
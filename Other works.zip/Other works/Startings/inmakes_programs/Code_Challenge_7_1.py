# Code Challenge 7
# Python - Code Challenge 7 01
# List out all the even numbers from 2 to 222 using lists in Python
for i in range(222):
    if i%2 ==0:
        print(i)
i+=1
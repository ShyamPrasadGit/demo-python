i=20
while i <30:
    i+=1
    if i == 22:
        continue
    print(i)

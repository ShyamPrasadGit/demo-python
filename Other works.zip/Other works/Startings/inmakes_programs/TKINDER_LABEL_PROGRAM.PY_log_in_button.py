from tkinter import  *
root=Tk()
label = Label(root,text ="hello world")
label.pack()
button=Button(root, text = "log in")
button.pack()
root.mainloop()

i=1
while 1<7:
    print(i)
    if i==3:
        break
    i+=1
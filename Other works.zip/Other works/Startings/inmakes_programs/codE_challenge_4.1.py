def divide_numbers(dividend, divisor):
    try:
        result = dividend / divisor
        return result
    except :
        print("Error: Division by zero is not allowed.")
        return None
a = int( input("Enter dividend : ",))
b = int( input("Enter dividend : "))
result = divide_numbers(a, b)
if result is not None:
    print(f"The result of {a} divided by {b} is : {result}")


x=[10,20,30,40]
for i in x:
    i+=10 #a. calculates the addition of each number
    print(i)
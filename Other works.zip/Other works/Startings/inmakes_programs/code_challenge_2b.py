for  i in range(10):
    if i==7:
        break
    print("I love my India")
def calculate_final_price(price_x, price_y):
    final_price = (price_x) / (price_y )**2
    return final_price

# Accept input from the user
price_x = float(input("Enter the price of product X: "))
price_y = float(input("Enter the price of product Y: "))

# Call the function and store the result in a variable
result = calculate_final_price(price_x, price_y)

# Print the final price
print("The final price is:", result)
#code challenge 7. 2
# List out all the odd numbers from 3 to 99 using lists in Python.
for i in range(3,99):
    if i%2 ==1:
        print(i)
i+=1
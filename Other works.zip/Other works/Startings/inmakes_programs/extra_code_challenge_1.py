month = ['January','February','March','April','May','June','July','August','September','October','November','December']
month_number = int(input("enter index of number ="))
if month_number > 12:
    print("You've entered Invalid input. Please enter a valid month inbdex")
elif month_number == 0:
    print("You've entered Invalid input. Please enter a valid month inbdex")
else:
    print("month is "+ month[month_number-1])


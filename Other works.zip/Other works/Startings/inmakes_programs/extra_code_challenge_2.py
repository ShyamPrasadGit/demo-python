def calculate_simple_interest(beginning_balance, number_of_periods,interest_rate):
    simple_interest = (beginning_balance*number_of_periods*interest_rate) / 100
    return simple_interest

p = float(input("Enter the beginning balance p: "))
n = float(input("Enter the number of periods n: "))
r = float(input("Enter the interest rate r: "))

simple_interest = calculate_simple_interest(p, n, r)
print("Simple interest is:", simple_interest)
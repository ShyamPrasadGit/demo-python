i=20
while i <=30:
    if i == 28:
        break
    print(i)
    i+=1
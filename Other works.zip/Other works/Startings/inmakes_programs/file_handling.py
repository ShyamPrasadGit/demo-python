file=open("fileprogram.txt","r")
content=file.read()
print(content)
file.close()

file=open("fileprogram.txt","a")
file.write("I am learning Python programing language")
file.close()
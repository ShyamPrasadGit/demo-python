a=10
mark=int(input("enter mark"))
if mark>=90:
    print("A grade")
elif mark>=80:
    print("B grade")
elif  mark>=70:
    print("C grade")
else:
    print("Failed")


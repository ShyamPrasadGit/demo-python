movies_list=["up","joji","2018","titanic","coda","spiderman","superman","batman"]
del movies_list[4] #Print a specified list after removing the 5th element.
print(movies_list)
movies_list.insert(4,"Zack_Snyder")  #Insert your favourite movie director name at the 4th index position of the list and print out the list elements.
print(movies_list)
print(movies_list[3]) #List out the 4th element in the list
movies_list.append("Jurasic Park")  #Add additional item to the current list and display the list.
print(movies_list)
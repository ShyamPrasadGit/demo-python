i=1
a=int(input("enter a value"))
while i<=a:
    print (i)
    i +=1
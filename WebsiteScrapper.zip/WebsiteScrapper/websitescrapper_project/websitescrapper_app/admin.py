from django.contrib import admin
from .  models import Links
# Register your models here.
admin.site.register(Links)